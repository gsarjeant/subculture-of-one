<?php /** @var string $moodPicker */ ?>
        <h1>How are you feeling?</h1>
        <main>
<?php echo $moodPicker; ?>
        </main>
