ALTER TABLE settings
ADD COLUMN strict_accessibility BOOLEAN DEFAULT TRUE;
