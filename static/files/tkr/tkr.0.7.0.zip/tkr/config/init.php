<?php
// initial configuration. These need to be set on first run so the app loads properly.
// Other settings can be defined in the admin page that loads on first run.
return [
    'base_url' => 'http://localhost',
    'base_path' => '/tkr/',
];
