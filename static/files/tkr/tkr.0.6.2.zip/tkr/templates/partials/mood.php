<?php /** @var string $moodPicker */ ?>
        <h2>How are you feeling?</h2>
<?php echo $moodPicker; ?>